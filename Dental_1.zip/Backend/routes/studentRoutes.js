import express from 'express';
import { uploadStudents, registerStudent, loginStudent, resetStudentPassword, getLoggedInStudent  } from '../controllers/studentController.js';
import { protectStudent } from '../middleware/authMiddleware.js';
import { upload, handleUploadErrors } from '../config/multer.js';

const router = express.Router();



router.post('/login', loginStudent);
router.post('/reset-password', resetStudentPassword);
router.get('/me', protectStudent, getLoggedInStudent);


//Register single student
router.post('/register', 
    registerStudent);


// Upload students from Excel
router.post('/upload', 
  upload.single('file'),
  handleUploadErrors,
  uploadStudents
);


export default router;